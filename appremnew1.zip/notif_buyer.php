<?php
// ===== NOTIFIKASI PESAN ADMIN UNTUK PEMBELI (angka di tombol Riwayat) =====
// Kolom pesanan.notif_buyer = 1 artinya admin baru memperbarui pesanan & pembeli belum melihatnya.
function alzz_ensure_notif_col($conn) {
    static $done = false;
    if ($done) return;
    $r = mysqli_query($conn, "SHOW COLUMNS FROM pesanan LIKE 'notif_buyer'");
    if (!$r || mysqli_num_rows($r) === 0) {
        mysqli_query($conn, "ALTER TABLE pesanan ADD COLUMN notif_buyer TINYINT(1) NOT NULL DEFAULT 0");
    }
    $done = true;
}

function alzz_buyer_notif_count($conn, $username) {
    alzz_ensure_notif_col($conn);
    $u = mysqli_real_escape_string($conn, $username);
    $r = mysqli_query($conn, "SELECT COUNT(*) AS n FROM pesanan WHERE username = '$u' AND notif_buyer = 1");
    if ($r && ($d = mysqli_fetch_assoc($r))) return intval($d['n']);
    return 0;
}

function alzz_notif_badge($n) {
    $show = $n > 0 ? 'inline-block' : 'none';
    $txt = $n > 99 ? '99+' : $n;
    return '<span class="notif-count" style="display:' . $show . ';background:#ef4444;color:#fff;font-size:9px;font-weight:bold;min-width:15px;height:15px;line-height:15px;padding:0 4px;box-sizing:border-box;border-radius:8px;text-align:center;margin-left:4px;vertical-align:middle;">' . $txt . '</span>';
}
