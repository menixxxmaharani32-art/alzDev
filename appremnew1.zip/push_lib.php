<?php
// ===== WEB PUSH (notifikasi ke layar HP, walau Chrome ditutup) =====
// Tanpa library tambahan. Memakai VAPID + push tanpa payload (isi notifikasi diambil oleh sw.js dari push_api.php).

function alzz_push_tables($conn) {
    static $done = false;
    if ($done) return;
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS push_config (k VARCHAR(50) PRIMARY KEY, v TEXT NOT NULL)");
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS push_subs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        endpoint_hash CHAR(64) NOT NULL UNIQUE,
        endpoint TEXT NOT NULL,
        created_at DATETIME NOT NULL
    )");
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS push_events (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(20) NOT NULL,
        title VARCHAR(200) NOT NULL,
        body VARCHAR(500) NOT NULL,
        url VARCHAR(200) NOT NULL,
        created_at DATETIME NOT NULL
    )");
    $done = true;
}

function alzz_b64u($bin) { return rtrim(strtr(base64_encode($bin), '+/', '-_'), '='); }

// Ambil / buat kunci VAPID (disimpan di database, dibuat otomatis sekali)
function alzz_vapid($conn) {
    alzz_push_tables($conn);
    $r = mysqli_query($conn, "SELECT k, v FROM push_config WHERE k IN ('vapid_private','vapid_public')");
    $cfg = [];
    while ($r && ($row = mysqli_fetch_assoc($r))) $cfg[$row['k']] = $row['v'];
    if (!empty($cfg['vapid_private']) && !empty($cfg['vapid_public'])) {
        return ['private' => $cfg['vapid_private'], 'public' => $cfg['vapid_public']];
    }
    $key = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
    if (!$key) return null;
    openssl_pkey_export($key, $pem);
    $d = openssl_pkey_get_details($key);
    $x = str_pad($d['ec']['x'], 32, "\0", STR_PAD_LEFT);
    $y = str_pad($d['ec']['y'], 32, "\0", STR_PAD_LEFT);
    $pub = alzz_b64u("\x04" . $x . $y);
    $p1 = mysqli_real_escape_string($conn, $pem);
    $p2 = mysqli_real_escape_string($conn, $pub);
    mysqli_query($conn, "REPLACE INTO push_config (k, v) VALUES ('vapid_private', '$p1'), ('vapid_public', '$p2')");
    return ['private' => $pem, 'public' => $pub];
}

// Tanda tangan DER (ECDSA) -> format mentah R||S 64 byte untuk JWT ES256
function alzz_der_to_raw($der) {
    $o = 2;
    if (ord($der[1]) & 0x80) $o += (ord($der[1]) & 0x7f);
    $rl = ord($der[$o + 1]);
    $r = substr($der, $o + 2, $rl);
    $o2 = $o + 2 + $rl;
    $sl = ord($der[$o2 + 1]);
    $s = substr($der, $o2 + 2, $sl);
    $r = str_pad(ltrim($r, "\0"), 32, "\0", STR_PAD_LEFT);
    $s = str_pad(ltrim($s, "\0"), 32, "\0", STR_PAD_LEFT);
    return $r . $s;
}

function alzz_vapid_header($vapid, $endpoint) {
    $u = parse_url($endpoint);
    $aud = $u['scheme'] . '://' . $u['host'] . (isset($u['port']) ? ':' . $u['port'] : '');
    $head = alzz_b64u(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
    $claims = alzz_b64u(json_encode(['aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => 'mailto:admin@alzzstore.local']));
    $data = $head . '.' . $claims;
    openssl_sign($data, $der, $vapid['private'], OPENSSL_ALGO_SHA256);
    $jwt = $data . '.' . alzz_b64u(alzz_der_to_raw($der));
    return 'vapid t=' . $jwt . ', k=' . $vapid['public'];
}

// Kirim 1 push kosong ke 1 endpoint. Return kode HTTP (0 jika gagal koneksi)
function alzz_push_send($vapid, $endpoint) {
    $headers = [
        'Authorization: ' . alzz_vapid_header($vapid, $endpoint),
        'TTL: 86400',
        'Urgency: high',
        'Content-Length: 0',
    ];
    if (function_exists('curl_init')) {
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => '',
            CURLOPT_HTTPHEADER => $headers, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 6, CURLOPT_CONNECTTIMEOUT => 4,
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $GLOBALS['alzz_push_last'] = ['code' => $code, 'error' => curl_error($ch), 'body' => is_string($body) ? substr($body, 0, 300) : ''];
        curl_close($ch);
        return $code;
    }
    $ctx = stream_context_create(['http' => ['method' => 'POST', 'header' => implode("\r\n", $headers), 'content' => '', 'timeout' => 6, 'ignore_errors' => true]]);
    @file_get_contents($endpoint, false, $ctx);
    if (!empty($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) return (int)$m[1];
    return 0;
}

// Catat kejadian + kirim push ke semua HP admin yang sudah mengaktifkan notifikasi
function alzz_push_event($conn, $type, $title, $body, $url) {
    try {
        alzz_push_tables($conn);
        $t = mysqli_real_escape_string($conn, mb_substr($title, 0, 190));
        $b = mysqli_real_escape_string($conn, mb_substr($body, 0, 480));
        $u = mysqli_real_escape_string($conn, $url);
        $ty = mysqli_real_escape_string($conn, $type);
        mysqli_query($conn, "DELETE FROM push_events WHERE created_at < DATE_SUB(NOW(), INTERVAL 2 DAY)");
        mysqli_query($conn, "INSERT INTO push_events (type, title, body, url, created_at) VALUES ('$ty', '$t', '$b', '$u', NOW())");
        $subs = mysqli_query($conn, "SELECT id, endpoint FROM push_subs");
        if (!$subs || mysqli_num_rows($subs) === 0) return;
        $vapid = alzz_vapid($conn);
        if (!$vapid) return;
        while ($s = mysqli_fetch_assoc($subs)) {
            $code = alzz_push_send($vapid, $s['endpoint']);
            if ($code === 404 || $code === 410) {
                mysqli_query($conn, "DELETE FROM push_subs WHERE id = " . intval($s['id']));
            }
        }
    } catch (Throwable $e) {
        // Jangan pernah menggagalkan proses pesanan/pendaftaran karena notifikasi
    }
}
