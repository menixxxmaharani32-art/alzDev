// Service worker ALZZ Store: menampilkan notifikasi di layar HP saat ada push dari server
var META = 'alzz-meta';

async function getMeta(key) {
  try {
    var c = await caches.open(META);
    var r = await c.match(key);
    return r ? await r.text() : null;
  } catch (e) { return null; }
}
async function setMeta(key, val) {
  try {
    var c = await caches.open(META);
    await c.put(key, new Response(String(val)));
  } catch (e) {}
}

self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });

async function handlePush() {
  var last = parseInt((await getMeta('last_id')) || '0', 10);
  var events = [];
  try {
    var res = await fetch('push_api.php?action=events&since=' + last, { credentials: 'same-origin', cache: 'no-store' });
    var data = await res.json();
    events = data.events || [];
  } catch (e) {}

  if (events.length === 0) {
    // Tidak ada yang baru (mungkin sudah ditampilkan): tampilkan ulang notifikasi terakhir dengan tag sama (diganti, bukan dobel)
    var saved = await getMeta('last_event');
    var ev = null;
    try { ev = saved ? JSON.parse(saved) : null; } catch (e) {}
    if (!ev) ev = { id: 0, title: 'ALZZ Store', body: 'Ada aktivitas baru di dashboard admin.', url: 'admin_dashboard.php' };
    return self.registration.showNotification(ev.title, {
      body: ev.body, tag: 'alzz-evt-' + ev.id, renotify: false,
      data: { url: ev.url }, icon: undefined
    });
  }

  var maxId = last;
  for (var i = 0; i < events.length; i++) {
    var e = events[i];
    if (e.id > maxId) maxId = e.id;
    await self.registration.showNotification(e.title, {
      body: e.body, tag: 'alzz-evt-' + e.id, renotify: true,
      vibrate: [200, 100, 200], data: { url: e.url }
    });
  }
  await setMeta('last_id', maxId);
  await setMeta('last_event', JSON.stringify(events[events.length - 1]));
}

self.addEventListener('push', function (event) {
  event.waitUntil(handlePush());
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  var url = (event.notification.data && event.notification.data.url) || 'admin_dashboard.php';
  var target = new URL(url, self.registration.scope).href;
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
      for (var i = 0; i < list.length; i++) {
        if ('focus' in list[i]) { list[i].navigate(target); return list[i].focus(); }
      }
      return self.clients.openWindow(target);
    })
  );
});
