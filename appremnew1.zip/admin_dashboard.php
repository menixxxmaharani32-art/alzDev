<?php
// Cegah halaman tersimpan di cache (tombol Back setelah logout)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

// Aktifkan pelacakan error
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'auth_guard.php';
require_once 'config.php';

// Cek apakah admin sudah login
if (empty($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header("Location: login.php");
    exit;
}

// ===== ENDPOINT NOTIFIKASI (dipanggil otomatis oleh JavaScript dashboard) =====
if (isset($_GET['notif'])) {
    header('Content-Type: application/json; charset=utf-8');
    $so = intval($_GET['o'] ?? 0); // id pesanan terakhir yang sudah dilihat
    $su = intval($_GET['u'] ?? 0); // id user terakhir yang sudah dilihat
    $out = ['max_order'=>0,'max_user'=>0,'new_orders'=>0,'new_users'=>0,'pending'=>0,'stok_habis'=>0,
            'last_order'=>null,'last_user'=>null,'habis_nama'=>''];

    $r = mysqli_query($conn, "SELECT MAX(id) AS m, SUM(id > $so) AS n, SUM(status = 'Pending') AS p FROM pesanan");
    if ($r && ($d = mysqli_fetch_assoc($r))) {
        $out['max_order'] = intval($d['m']); $out['new_orders'] = intval($d['n']); $out['pending'] = intval($d['p']);
    }
    $r = mysqli_query($conn, "SELECT p.id, p.username, p.nama, pr.nama_app FROM pesanan p LEFT JOIN produk pr ON p.produk_id = pr.id ORDER BY p.id DESC LIMIT 1");
    if ($r && ($d = mysqli_fetch_assoc($r))) {
        $out['last_order'] = ['id'=>intval($d['id']), 'user'=>($d['username'] ?: ($d['nama'] ?: 'Guest')), 'produk'=>($d['nama_app'] ?? '')];
    }
    $r = mysqli_query($conn, "SELECT MAX(id) AS m, SUM(id > $su) AS n FROM buyers");
    if ($r && ($d = mysqli_fetch_assoc($r))) {
        $out['max_user'] = intval($d['m']); $out['new_users'] = intval($d['n']);
    }
    $r = mysqli_query($conn, "SELECT username FROM buyers ORDER BY id DESC LIMIT 1");
    if ($r && ($d = mysqli_fetch_assoc($r))) { $out['last_user'] = $d['username']; }
    $r = mysqli_query($conn, "SELECT COUNT(*) AS n, GROUP_CONCAT(nama_app SEPARATOR ', ') AS nm FROM produk WHERE stok <= 0");
    if ($r && ($d = mysqli_fetch_assoc($r))) { $out['stok_habis'] = intval($d['n']); $out['habis_nama'] = (string)$d['nm']; }

    echo json_encode($out);
    exit;
}

// Tentukan tab aktif berdasarkan URL (?tab=...)
$active_tab = $_GET['tab'] ?? 'situs';

// 1. Proses Update Pesanan
if (isset($_POST['update_pesanan'])) {
    $id_pesanan = intval($_POST['pesanan_id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $data_pesanan = mysqli_real_escape_string($conn, $_POST['data_pesanan']);
    $cara_login = mysqli_real_escape_string($conn, $_POST['cara_login']);
    
    // Cek apakah admin benar-benar mengubah sesuatu (untuk memunculkan angka notifikasi di riwayat pembeli)
    require_once 'notif_buyer.php';
    alzz_ensure_notif_col($conn);
    $old_row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT status, data_pesanan, cara_login FROM pesanan WHERE id = $id_pesanan"));
    $berubah = !$old_row
        || trim((string)$old_row['status']) !== trim($_POST['status'])
        || trim((string)$old_row['data_pesanan']) !== trim($_POST['data_pesanan'])
        || trim((string)($old_row['cara_login'] ?? '')) !== trim($_POST['cara_login']);

    $update_query = "UPDATE pesanan SET status = '$status', data_pesanan = '$data_pesanan', cara_login = '$cara_login' WHERE id = $id_pesanan";
    if (!mysqli_query($conn, $update_query)) {
        mysqli_query($conn, "UPDATE pesanan SET status = '$status', data_pesanan = '$data_pesanan' WHERE id = $id_pesanan");
    }
    if ($berubah) {
        mysqli_query($conn, "UPDATE pesanan SET notif_buyer = 1 WHERE id = $id_pesanan");
    }
    
    header("Location: admin_dashboard.php?tab=situs");
    exit;
}

// 2. Proses Hapus Pesanan
if (isset($_GET['hapus_pesanan'])) {
    $id_pesanan = intval($_GET['hapus_pesanan']);
    mysqli_query($conn, "DELETE FROM pesanan WHERE id = $id_pesanan");
    header("Location: admin_dashboard.php?tab=situs");
    exit;
}

// 3. Proses Tambah Produk
if (isset($_POST['tambah_produk'])) {
    $nama_app = mysqli_real_escape_string($conn, $_POST['nama_app']);
    $harga = intval($_POST['harga']);
    $stok = intval($_POST['stok']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $foto_produk = mysqli_real_escape_string($conn, $_POST['foto_produk']);
    $durasi = mysqli_real_escape_string($conn, $_POST['durasi']);
    $plan = mysqli_real_escape_string($conn, $_POST['plan']);
    
    mysqli_query($conn, "INSERT INTO produk (nama_app, harga, stok, deskripsi, foto_produk, durasi, plan) VALUES ('$nama_app', '$harga', '$stok', '$deskripsi', '$foto_produk', '$durasi', '$plan')");
    header("Location: admin_dashboard.php?tab=produk");
    exit;
}

// 4. Proses Update / Edit Harga dan Stok Produk
if (isset($_POST['update_produk'])) {
    $prod_id = intval($_POST['produk_id']);
    $harga_baru = intval($_POST['harga']);
    $stok_baru = intval($_POST['stok']);
    
    mysqli_query($conn, "UPDATE produk SET harga = $harga_baru, stok = $stok_baru WHERE id = $prod_id");
    header("Location: admin_dashboard.php?tab=produk");
    exit;
}

// 5. Proses Hapus Produk
if (isset($_GET['hapus_produk'])) {
    $id = intval($_GET['hapus_produk']);
    mysqli_query($conn, "DELETE FROM produk WHERE id = $id");
    header("Location: admin_dashboard.php?tab=produk");
    exit;
}

// 6. Proses Tambah Metode Pembayaran
if (isset($_POST['tambah_metode'])) {
    $nama_metode  = mysqli_real_escape_string($conn, $_POST['nama_metode']);
    $nomor_tujuan = mysqli_real_escape_string($conn, $_POST['nomor_tujuan']);
    $pemilik      = !empty($_POST['pemilik']) ? mysqli_real_escape_string($conn, $_POST['pemilik']) : '-';
    
    $query_metode = "INSERT INTO metode_pembayaran (nama_metode, nomor_tujuan, status) VALUES ('$nama_metode', '$nomor_tujuan', '$pemilik')";
    mysqli_query($conn, $query_metode);
    
    header("Location: admin_dashboard.php?tab=pembayaran");
    exit;
}

// 7. Proses Hapus Metode Pembayaran
if (isset($_GET['hapus_metode'])) {
    $id = intval($_GET['hapus_metode']);
    mysqli_query($conn, "DELETE FROM metode_pembayaran WHERE id = $id");
    header("Location: admin_dashboard.php?tab=pembayaran");
    exit;
}

// 8. Proses Update Pengaturan Situs & Nomor WhatsApp Admin
if (isset($_POST['update_pengaturan'])) {
    $banner_url = mysqli_real_escape_string($conn, $_POST['banner_url']);
    $music_raw = trim($_POST['music_url'] ?? '');
    // Hapus musik
    if (!empty($_POST['hapus_music'])) { $music_raw = ''; }
    // Upload file musik langsung dari HP (mp3/m4a/ogg/wav, maks 15MB)
    if (isset($_FILES['music_file']) && $_FILES['music_file']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['music_file']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['mp3', 'm4a', 'ogg', 'wav', 'aac'], true) && $_FILES['music_file']['size'] <= 15 * 1024 * 1024) {
            if (!is_dir('uploads')) { mkdir('uploads', 0777, true); }
            $music_path = 'uploads/music_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['music_file']['tmp_name'], $music_path)) {
                $music_raw = $music_path;
            }
        }
    }
    $music_url = mysqli_real_escape_string($conn, $music_raw);
    $no_wa = mysqli_real_escape_string($conn, $_POST['no_wa']);
    
    $cek_admin = mysqli_query($conn, "SELECT * FROM admin LIMIT 1");
    if ($cek_admin && mysqli_num_rows($cek_admin) > 0) {
        mysqli_query($conn, "UPDATE admin SET banner_url = '$banner_url', music_url = '$music_url', no_wa = '$no_wa' LIMIT 1");
    } else {
        mysqli_query($conn, "INSERT INTO admin (banner_url, music_url, no_wa) VALUES ('$banner_url', '$music_url', '$no_wa')");
    }

    header("Location: admin_dashboard.php?tab=situs");
    exit;
}

// 9. Proses Hapus User Pembeli
if (isset($_GET['hapus_user'])) {
    $id_user = intval($_GET['hapus_user']);
    mysqli_query($conn, "DELETE FROM buyers WHERE id = $id_user");
    header("Location: admin_dashboard.php?tab=users");
    exit;
}

$admin_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin LIMIT 1"));
$produk_result = mysqli_query($conn, "SELECT * FROM produk");
$metode_result = mysqli_query($conn, "SELECT * FROM metode_pembayaran");
$pesanan_result = mysqli_query($conn, "SELECT p.*, pr.nama_app, pr.durasi, pr.plan FROM pesanan p JOIN produk pr ON p.produk_id = pr.id ORDER BY p.id DESC");
$buyers_result = mysqli_query($conn, "SELECT * FROM buyers ORDER BY id DESC");
$__mo = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(MAX(id),0) AS m FROM pesanan"));
$__mu = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(MAX(id),0) AS m FROM buyers"));
$page_max_order = intval($__mo['m'] ?? 0);
$page_max_user  = intval($__mu['m'] ?? 0);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ALZZ Development</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
    <style>
        body {
            padding-bottom: 90px !important;
            background-color: #0d1117;
            color: #fff;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        .admin-nav-bar {
            position: fixed;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100%;
            max-width: 480px;
            background: #0d1527;
            border-top: 1px solid #38bdf8;
            display: flex;
            justify-content: space-around;
            padding: 10px 4px;
            z-index: 9999;
            box-sizing: border-box;
            box-shadow: 0 -4px 15px rgba(0,0,0,0.5);
        }
        .admin-nav-link {
            background: rgba(56, 189, 248, 0.08);
            border: 1px solid #38bdf8;
            color: #38bdf8;
            font-size: 10px;
            font-weight: bold;
            padding: 8px 0;
            border-radius: 6px;
            text-align: center;
            text-decoration: none;
            flex: 1;
            margin: 0 2px;
        }
        .admin-nav-link.active-tab {
            background: #38bdf8;
            color: #000;
        }
        /* ===== NOTIFIKASI ===== */
        .admin-nav-link { position: relative; }
        .nav-badge {
            position: absolute; top: -6px; right: 4px;
            min-width: 16px; height: 16px; padding: 0 4px; box-sizing: border-box;
            background: #ef4444; color: #fff; border-radius: 8px;
            font-size: 9px; line-height: 16px; font-weight: bold; text-align: center;
            display: none;
        }
        #toast-wrap {
            position: fixed; top: 10px; left: 50%; transform: translateX(-50%);
            width: calc(100% - 20px); max-width: 460px; z-index: 10000;
            display: flex; flex-direction: column; gap: 8px; pointer-events: none;
        }
        .notif-toast {
            pointer-events: auto; cursor: pointer;
            background: #0d1527; color: #fff; border: 1px solid #38bdf8; border-left-width: 5px;
            border-radius: 8px; padding: 10px 12px; font-size: 12px;
            box-shadow: 0 4px 18px rgba(0,0,0,0.6);
            animation: toastIn .25s ease-out;
        }
        .notif-toast strong { color: #38bdf8; display: block; font-size: 12px; margin-bottom: 2px; }
        .notif-toast small { color: #94a3b8; font-size: 10px; }
        .notif-toast.warn { border-color: #facc15; }
        .notif-toast.warn strong { color: #facc15; }
        @keyframes toastIn { from { opacity: 0; transform: translateY(-12px); } to { opacity: 1; transform: none; } }
        #notif-bell {
            background: rgba(56,189,248,0.1); border: 1px solid #38bdf8; color: #38bdf8;
            border-radius: 6px; font-size: 12px; padding: 4px 8px; cursor: pointer;
        }
        #notif-bell.on { background: #38bdf8; color: #000; }
    </style>
</head>
<body>
    <div class="mobile-container">
        
        <!-- HEADER DASHBOARD -->
        <div class="section-header">
            <h2 class="catalog-title">
                <span class="catalog-text">ADMIN DASHBOARD</span>
            </h2>
            <div style="display: flex; gap: 8px;">
                <a href="index.php" class="admin-link">Beranda</a>
                <a href="logout.php" class="admin-link" style="background: #ef4444; border-color: #ef4444;">Logout</a>
            </div>
        </div>

        <!-- TAB 1: SITUS & PESANAN -->
        <div id="tab-situs" class="tab-content <?php echo ($active_tab == 'situs') ? 'active' : ''; ?>">
            
            <!-- Pengaturan Situs & Kontak -->
            <div class="admin-card" style="margin-bottom: 16px; border-color: #38bdf8;">
                <h3 style="color: #38bdf8; font-size: 13px; margin-bottom: 10px;">Pengaturan Situs & Kontak</h3>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div style="margin-bottom: 8px;">
                        <label style="color: #cbd5e1; font-size: 10px; display: block; margin-bottom: 2px;">URL Banner / Foto Utama:</label>
                        <input type="text" name="banner_url" value="<?php echo htmlspecialchars($admin_data['banner_url'] ?? ''); ?>" placeholder="https://files.catbox.moe/xxxxx.jpg" style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <div style="margin-bottom: 8px;">
                        <label style="color: #cbd5e1; font-size: 10px; display: block; margin-bottom: 2px;">URL Musik MP3 (Opsional):</label>
                        <input type="text" name="music_url" value="<?php echo htmlspecialchars($admin_data['music_url'] ?? ''); ?>" placeholder="https://.../music.mp3" style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                        <label style="color: #cbd5e1; font-size: 10px; display: block; margin: 8px 0 2px;">Atau upload file musik dari HP (mp3/m4a/ogg/wav, maks 15MB):</label>
                        <input type="file" name="music_file" accept="audio/*" style="width: 100%; color: #cbd5e1; font-size: 11px;">
                        <?php if (!empty($admin_data['music_url'])): ?>
                            <div style="margin-top: 8px; color: #94a3b8; font-size: 10px;">Musik saat ini (putar untuk tes):</div>
                            <audio controls preload="none" src="<?php echo htmlspecialchars($admin_data['music_url']); ?>" style="width: 100%; margin-top: 4px;"></audio>
                            <label style="color: #f87171; font-size: 10px; display: block; margin-top: 6px;">
                                <input type="checkbox" name="hapus_music" value="1"> Hapus musik (matikan backsound)
                            </label>
                        <?php endif; ?>
                    </div>
                    <div style="margin-bottom: 12px;">
                        <label style="color: #cbd5e1; font-size: 10px; display: block; margin-bottom: 2px;">Nomor WhatsApp Admin (Awali 62):</label>
                        <input type="text" name="no_wa" value="<?php echo htmlspecialchars($admin_data['no_wa'] ?? ''); ?>" placeholder="628123456789" style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <button type="submit" name="update_pengaturan" class="btn-buy-mini" style="width: 100%; padding: 8px; font-size: 11px; cursor: pointer;">Simpan Pengaturan Situs</button>
                </form>
            </div>

            <!-- Kelola Pesanan Masuk -->
            <div class="admin-card" style="margin-bottom: 16px;">
                <h3 style="color: #38bdf8; font-size: 13px; margin-bottom: 10px;">Kelola Pesanan Masuk</h3>
                <?php if ($pesanan_result && mysqli_num_rows($pesanan_result) > 0): ?>
                    <?php while($ord = mysqli_fetch_assoc($pesanan_result)): ?>
                        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 10px; margin-bottom: 12px; font-size: 11px;">
                            
                            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                                <strong style="color: #38bdf8; font-size: 12px;">
                                    ID: #<?php echo $ord['id']; ?> - <?php echo htmlspecialchars($ord['nama_app']); ?>
                                    <?php if (!empty($ord['durasi']) || !empty($ord['plan'])): ?>
                                        <span style="color: #facc15; font-size: 11px;">
                                            (<?php echo htmlspecialchars($ord['durasi'] ?? ''); ?> <?php echo !empty($ord['plan']) ? '- '.htmlspecialchars($ord['plan']) : ''; ?>)
                                        </span>
                                    <?php endif; ?>
                                </strong>
                                <a href="admin_dashboard.php?hapus_pesanan=<?php echo $ord['id']; ?>&tab=situs" onclick="return confirm('Hapus pesanan ini dari dashboard?')" style="color: #ef4444; text-decoration: none; font-weight: bold; font-size: 10px; background: rgba(239, 68, 68, 0.1); padding: 2px 6px; border-radius: 4px; border: 1px solid #ef4444;">Hapus</a>
                            </div>
                            
                            <!-- INFORMASI USERNAME DAN DETAIL PEMBELI -->
                            <div style="margin-top: 4px; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 4px;">
                                <div>Akun Username: <strong style="color: #38bdf8;"><?php echo htmlspecialchars($ord['username'] ?? 'Guest'); ?></strong></div>
                                <div>Nama Pembeli: <strong style="color: #fff;"><?php echo htmlspecialchars($ord['nama'] ?? '-'); ?></strong></div>
                                <div>Alamat: <strong style="color: #cbd5e1;"><?php echo htmlspecialchars($ord['alamat'] ?? '-'); ?></strong></div>
                                <div>Device: <strong style="color: #38bdf8;"><?php echo htmlspecialchars($ord['device'] ?? '-'); ?></strong></div>
                            </div>

                            <div style="margin-top: 4px;">Tgl: <?php echo $ord['tanggal']; ?></div>
                            <div>Metode: <strong><?php echo htmlspecialchars($ord['metode_pembayaran']); ?></strong></div>
                            
                            <?php if (!empty($ord['bukti_pembayaran'])): ?>
                                <div style="margin-top: 6px;">
                                    <a href="<?php echo htmlspecialchars($ord['bukti_pembayaran']); ?>" target="_blank" style="color: #38bdf8; text-decoration: underline; font-weight: bold;">[ Lihat Foto Bukti Pembayaran ]</a>
                                </div>
                            <?php endif; ?>

                            <form action="" method="POST" style="margin-top: 8px;">
                                <input type="hidden" name="pesanan_id" value="<?php echo $ord['id']; ?>">
                                
                                <div style="margin-bottom: 6px;">
                                    <label style="color: #cbd5e1; font-size: 10px; display: block; margin-bottom: 2px;">Status:</label>
                                    <select name="status" style="width: 100%; padding: 6px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 10px;">
                                        <option value="Pending" <?php echo ($ord['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                        <option value="Dikonfirmasi" <?php echo ($ord['status'] == 'Dikonfirmasi') ? 'selected' : ''; ?>>Dikonfirmasi</option>
                                        <option value="Selesai" <?php echo ($ord['status'] == 'Selesai') ? 'selected' : ''; ?>>Selesai</option>
                                    </select>
                                </div>

                                <div style="margin-bottom: 6px;">
                                    <label style="color: #cbd5e1; font-size: 10px; display: block; margin-bottom: 2px;">Data Akun / Pesanan:</label>
                                    <textarea name="data_pesanan" rows="2" style="width: 100%; padding: 6px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 10px;"><?php echo htmlspecialchars($ord['data_pesanan'] ?? ''); ?></textarea>
                                </div>

                                <div style="margin-bottom: 6px;">
                                    <label style="color: #38bdf8; font-size: 10px; display: block; margin-bottom: 2px;">Cara Login:</label>
                                    <textarea name="cara_login" rows="2" style="width: 100%; padding: 6px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 10px;"><?php echo htmlspecialchars($ord['cara_login'] ?? ''); ?></textarea>
                                </div>

                                <button type="submit" name="update_pesanan" style="background: #38bdf8; color: #000; border: none; padding: 6px 12px; border-radius: 6px; font-weight: bold; font-size: 10px; cursor: pointer;">Simpan Perubahan</button>
                            </form>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="color: #94a3b8; font-size: 11px; text-align: center;">Belum ada pesanan masuk.</p>
                <?php endif; ?>
            </div>

        </div>

        <!-- TAB 2: METODE PEMBAYARAN -->
        <div id="tab-pembayaran" class="tab-content <?php echo ($active_tab == 'pembayaran') ? 'active' : ''; ?>">
            <div class="admin-card" style="margin-bottom: 16px;">
                <h3 style="color: #38bdf8; font-size: 13px; margin-bottom: 10px;">Metode Pembayaran</h3>
                
                <form action="" method="POST" style="margin-bottom: 14px;">
                    <div style="margin-bottom: 8px;">
                        <input type="text" name="nama_metode" placeholder="Nama Metode (Contoh: QRIS / DANA)" required style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <div style="margin-bottom: 8px;">
                        <input type="text" name="nomor_tujuan" placeholder="Nomor Tujuan atau URL Gambar QRIS" required style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <div style="margin-bottom: 8px;">
                        <input type="text" name="pemilik" placeholder="Atas Nama (Opsional)" style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <button type="submit" name="tambah_metode" class="btn-buy-mini" style="width: 100%; padding: 8px; font-size: 11px; cursor: pointer;">Tambah Metode</button>
                </form>

                <div style="font-size: 11px;">
                    <strong style="color: #cbd5e1; display: block; margin-bottom: 6px;">Daftar Metode:</strong>
                    <?php if ($metode_result && mysqli_num_rows($metode_result) > 0): ?>
                        <?php while($m = mysqli_fetch_assoc($metode_result)): ?>
                            <?php 
                                $nama_m = $m['nama_metode'];
                                $tujuan_m = $m['nomor_tujuan'];
                                $status_m = trim($m['status'] ?? '');
                                $nama_pemilik = (!empty($status_m) && $status_m !== '-') ? ' (a.n ' . $status_m . ')' : ''; 
                                $is_img = (filter_var($tujuan_m, FILTER_VALIDATE_URL) || stripos($nama_m, 'qris') !== false);
                            ?>
                            <div style="background: rgba(255,255,255,0.03); padding: 8px; border-radius: 6px; margin-bottom: 8px; border: 1px solid rgba(255,255,255,0.08);">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                                    <div>
                                        <strong><?php echo htmlspecialchars($nama_m); ?></strong><?php echo htmlspecialchars($nama_pemilik); ?>
                                    </div>
                                    <a href="admin_dashboard.php?hapus_metode=<?php echo $m['id']; ?>&tab=pembayaran" onclick="return confirm('Hapus metode ini?')" style="color: #ef4444; text-decoration: none; font-weight: bold; font-size: 10px;">Hapus</a>
                                </div>
                                <?php if ($is_img && filter_var($tujuan_m, FILTER_VALIDATE_URL)): ?>
                                    <div style="margin-top: 4px;">
                                        <img src="<?php echo htmlspecialchars($tujuan_m); ?>" alt="QRIS" style="max-width: 100px; border-radius: 4px; border: 1px solid #fff; display: block; margin-bottom: 4px;">
                                        <a href="<?php echo htmlspecialchars($tujuan_m); ?>" download target="_blank" style="color: #38bdf8; font-size: 10px; text-decoration: underline;">Download Gambar QRIS</a>
                                    </div>
                                <?php else: ?>
                                    <div style="color: #cbd5e1; font-size: 10px;">Tujuan: <strong><?php echo htmlspecialchars($tujuan_m); ?></strong></div>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="color: #94a3b8; font-size: 10px;">Belum ada metode pembayaran.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- TAB 3: PRODUK -->
        <div id="tab-produk" class="tab-content <?php echo ($active_tab == 'produk') ? 'active' : ''; ?>">
            
            <!-- Tambah Produk Baru -->
            <div class="admin-card" style="margin-bottom: 16px;">
                <h3 style="color: #38bdf8; font-size: 13px; margin-bottom: 10px;">Tambah Produk Baru</h3>
                
                <form action="" method="POST">
                    <div style="margin-bottom: 8px;">
                        <input type="text" name="nama_app" placeholder="Nama Aplikasi / Produk" required style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <div style="margin-bottom: 8px;">
                        <input type="number" name="harga" placeholder="Harga (Contoh: 15000)" required style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <div style="margin-bottom: 8px;">
                        <input type="number" name="stok" placeholder="Jumlah Stok" required style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <div style="margin-bottom: 8px;">
                        <input type="text" name="foto_produk" placeholder="URL Foto Produk (Catbox / Gambar)" required style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <div style="display: flex; gap: 8px; margin-bottom: 8px;">
                        <input type="text" name="durasi" placeholder="Durasi (1 Bulan)" style="width: 50%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                        <input type="text" name="plan" placeholder="Plan (Sharing)" style="width: 50%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;">
                    </div>
                    <div style="margin-bottom: 8px;">
                        <textarea name="deskripsi" placeholder="Deskripsi singkat produk..." rows="2" style="width: 100%; padding: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 6px; color: #fff; font-size: 11px;"></textarea>
                    </div>
                    <button type="submit" name="tambah_produk" class="btn-buy-mini" style="width: 100%; padding: 8px; font-size: 11px; cursor: pointer;">Tambah Produk</button>
                </form>
            </div>

            <!-- Daftar Produk & Edit Stok/Harga -->
            <div class="admin-card" style="margin-bottom: 16px;">
                <h3 style="color: #38bdf8; font-size: 13px; margin-bottom: 10px;">Daftar Produk & Edit Stok/Harga</h3>
                
                <div style="font-size: 11px;">
                    <?php if ($produk_result && mysqli_num_rows($produk_result) > 0): ?>
                        <?php while($prod = mysqli_fetch_assoc($produk_result)): ?>
                            <div style="background: rgba(255,255,255,0.03); padding: 10px; border-radius: 8px; margin-bottom: 10px; border: 1px solid rgba(255,255,255,0.08);">
                                
                                <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 8px;">
                                    <img src="<?php echo htmlspecialchars($prod['foto_produk']); ?>" alt="" style="width: 45px; height: 45px; object-fit: cover; border-radius: 6px; border: 1px solid rgba(255,255,255,0.2);">
                                    <div style="flex-grow: 1;">
                                        <strong style="color: #fff; font-size: 12px; display: block;"><?php echo htmlspecialchars($prod['nama_app']); ?></strong>
                                        <span style="color: #38bdf8; font-size: 10px;"><?php echo htmlspecialchars($prod['durasi'] ?? ''); ?> <?php echo !empty($prod['plan']) ? '- '.htmlspecialchars($prod['plan']) : ''; ?></span>
                                    </div>
                                    <a href="admin_dashboard.php?hapus_produk=<?php echo $prod['id']; ?>&tab=produk" onclick="return confirm('Hapus produk ini?')" style="color: #ef4444; text-decoration: none; font-weight: bold; font-size: 10px; background: rgba(239, 68, 68, 0.1); padding: 4px 8px; border-radius: 4px; border: 1px solid #ef4444;">Hapus</a>
                                </div>

                                <form action="" method="POST" style="display: flex; gap: 6px; align-items: center;">
                                    <input type="hidden" name="produk_id" value="<?php echo $prod['id']; ?>">
                                    
                                    <div style="flex: 1;">
                                        <label style="font-size: 9px; color: #94a3b8; display: block;">Harga (Rp):</label>
                                        <input type="number" name="harga" value="<?php echo $prod['harga']; ?>" required style="width: 100%; padding: 4px 6px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 4px; color: #fff; font-size: 11px;">
                                    </div>
                                    
                                    <div style="flex: 1;">
                                        <label style="font-size: 9px; color: #94a3b8; display: block;">Stok:</label>
                                        <input type="number" name="stok" value="<?php echo $prod['stok']; ?>" required style="width: 100%; padding: 4px 6px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 4px; color: #fff; font-size: 11px;">
                                    </div>
                                    
                                    <div style="padding-top: 14px;">
                                        <button type="submit" name="update_produk" style="background: #34d399; color: #000; border: none; padding: 6px 10px; border-radius: 4px; font-weight: bold; font-size: 10px; cursor: pointer;">Update</button>
                                    </div>
                                </form>

                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="color: #94a3b8; font-size: 10px; text-align: center;">Belum ada produk.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <!-- TAB 4: DAFTAR USER / BUYERS -->
        <div id="tab-users" class="tab-content <?php echo ($active_tab == 'users') ? 'active' : ''; ?>">
            <div class="admin-card" style="margin-bottom: 16px;">
                <h3 style="color: #38bdf8; font-size: 13px; margin-bottom: 10px;">Daftar Akun Buyer Terdaftar</h3>
                
                <div style="font-size: 11px;">
                    <?php if ($buyers_result && mysqli_num_rows($buyers_result) > 0): ?>
                        <?php while($user = mysqli_fetch_assoc($buyers_result)): ?>
                            <div style="background: rgba(255,255,255,0.03); padding: 10px; border-radius: 8px; margin-bottom: 8px; border: 1px solid rgba(255,255,255,0.08); display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <strong style="color: #38bdf8; font-size: 12px; display: block;">👤 <?php echo htmlspecialchars($user['username']); ?></strong>
                                    <span style="color: #94a3b8; font-size: 9px;">Tgl Daftar: <?php echo $user['created_at']; ?></span>
                                </div>
                                <a href="admin_dashboard.php?hapus_user=<?php echo $user['id']; ?>&tab=users" onclick="return confirm('Hapus akun buyer ini?')" style="color: #ef4444; text-decoration: none; font-weight: bold; font-size: 10px; background: rgba(239, 68, 68, 0.1); padding: 4px 8px; border-radius: 4px; border: 1px solid #ef4444;">Hapus</a>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="color: #94a3b8; font-size: 10px; text-align: center;">Belum ada buyer terdaftar.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>

    <!-- 4 TOMBOL NAVIGASI BAWAH (BERBASIS URL PARAM) -->
    <div class="admin-nav-bar">
        <a href="admin_dashboard.php?tab=situs" class="admin-nav-link <?php echo ($active_tab == 'situs') ? 'active-tab' : ''; ?>">Situs & Pesanan</a>
        <a href="admin_dashboard.php?tab=pembayaran" class="admin-nav-link <?php echo ($active_tab == 'pembayaran') ? 'active-tab' : ''; ?>">Pembayaran</a>
        <a href="admin_dashboard.php?tab=produk" class="admin-nav-link <?php echo ($active_tab == 'produk') ? 'active-tab' : ''; ?>">Produk</a>
        <a href="admin_dashboard.php?tab=users" class="admin-nav-link <?php echo ($active_tab == 'users') ? 'active-tab' : ''; ?>">Daftar User</a>
    </div>

    <div id="toast-wrap"></div>

    <script>
    (function () {
        var ACTIVE_TAB = <?php echo json_encode($active_tab); ?>;
        var PAGE_MAX_ORDER = <?php echo $page_max_order; ?>;
        var PAGE_MAX_USER  = <?php echo $page_max_user; ?>;
        var POLL_MS = 8000;

        function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
        function lsSet(k, v) { try { localStorage.setItem(k, String(v)); } catch (e) {} }

        // Penanda "terakhir dilihat" (disimpan di HP)
        var seenOrder = lsGet('alzz_seen_order'); var seenUser = lsGet('alzz_seen_user');
        seenOrder = (seenOrder === null) ? PAGE_MAX_ORDER : parseInt(seenOrder, 10);
        seenUser  = (seenUser  === null) ? PAGE_MAX_USER  : parseInt(seenUser, 10);
        if (ACTIVE_TAB === 'situs') seenOrder = PAGE_MAX_ORDER;   // sedang melihat daftar pesanan
        if (ACTIVE_TAB === 'users') seenUser  = PAGE_MAX_USER;    // sedang melihat daftar user
        lsSet('alzz_seen_order', seenOrder); lsSet('alzz_seen_user', seenUser);

        var notifiedOrder = null, notifiedUser = null, lastHabis = parseInt(lsGet('alzz_habis') || '0', 10);
        var firstPoll = true;
        var pushActive = false; // true jika HP ini sudah berlangganan push (notif layar HP)

        // ----- Badge di menu bawah -----
        function badgeFor(hrefPart) {
            var a = document.querySelector('.admin-nav-link[href*="' + hrefPart + '"]');
            if (!a) return null;
            var b = a.querySelector('.nav-badge');
            if (!b) { b = document.createElement('span'); b.className = 'nav-badge'; a.appendChild(b); }
            return b;
        }
        function setBadge(b, n) {
            if (!b) return;
            if (n > 0) { b.textContent = n > 99 ? '99+' : n; b.style.display = 'block'; }
            else { b.style.display = 'none'; }
        }

        // ----- Suara & getar -----
        var audioCtx = null;
        function unlockAudio() {
            try {
                var AC = window.AudioContext || window.webkitAudioContext;
                if (AC && !audioCtx) audioCtx = new AC();
                if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
            } catch (e) {}
        }
        document.addEventListener('touchstart', unlockAudio, { passive: true });
        document.addEventListener('click', unlockAudio);
        function beep() {
            try {
                if (!audioCtx) return;
                [880, 1175].forEach(function (f, i) {
                    var o = audioCtx.createOscillator(), g = audioCtx.createGain();
                    o.type = 'sine'; o.frequency.value = f;
                    o.connect(g); g.connect(audioCtx.destination);
                    var t = audioCtx.currentTime + i * 0.18;
                    g.gain.setValueAtTime(0.0001, t);
                    g.gain.exponentialRampToValueAtTime(0.25, t + 0.02);
                    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
                    o.start(t); o.stop(t + 0.18);
                });
            } catch (e) {}
            try { if (navigator.vibrate) navigator.vibrate([200, 100, 200]); } catch (e) {}
        }

        // ----- Toast di dalam dashboard -----
        function toast(title, body, targetUrl, warn) {
            var wrap = document.getElementById('toast-wrap');
            var d = document.createElement('div');
            d.className = 'notif-toast' + (warn ? ' warn' : '');
            var st = document.createElement('strong'); st.textContent = title;
            var tx = document.createElement('div'); tx.textContent = body;
            var sm = document.createElement('small'); sm.textContent = 'Ketuk untuk membuka';
            d.appendChild(st); d.appendChild(tx); d.appendChild(sm);
            d.onclick = function () { window.location.href = targetUrl; };
            wrap.appendChild(d);
            setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 12000);
            beep();
            // Notifikasi sistem HP (jika sudah diizinkan)
            try {
                if (!pushActive && 'Notification' in window && Notification.permission === 'granted') {
                    var n = new Notification(title, { body: body, tag: 'alzz-' + title });
                    n.onclick = function () { window.focus(); window.location.href = targetUrl; };
                }
            } catch (e) {}
        }

        // ----- Tombol lonceng: aktifkan notifikasi di layar HP (Web Push) -----
        function b64uToUint8(b64u) {
            var pad = '='.repeat((4 - b64u.length % 4) % 4);
            var raw = atob((b64u + pad).replace(/-/g, '+').replace(/_/g, '/'));
            var arr = new Uint8Array(raw.length);
            for (var i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
            return arr;
        }
        var pushSupported = ('serviceWorker' in navigator) && ('PushManager' in window) && ('Notification' in window);

        function sendSub(sub, action) {
            return fetch('push_api.php?action=' + action, {
                method: 'POST', credentials: 'same-origin',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(sub.toJSON ? sub.toJSON() : sub)
            }).then(function (r) { return r.json(); });
        }

        function sameKey(sub, keyBytes) {
            try {
                var cur = sub.options && sub.options.applicationServerKey;
                if (!cur) return false;
                var a = new Uint8Array(cur);
                if (a.length !== keyBytes.length) return false;
                for (var i = 0; i < a.length; i++) if (a[i] !== keyBytes[i]) return false;
                return true;
            } catch (e) { return false; }
        }

        // force = true: buang langganan lama lalu buat yang baru (mengatasi langganan kedaluwarsa)
        function enablePush(force) {
            return navigator.serviceWorker.register('sw.js').then(function () {
                return navigator.serviceWorker.ready;
            }).then(function (reg) {
                return fetch('push_api.php?action=key', { credentials: 'same-origin', cache: 'no-store' })
                    .then(function (r) { return r.json(); })
                    .then(function (k) {
                        if (!k.key) throw new Error('Kunci VAPID gagal dibuat (cek openssl di hosting).');
                        var keyBytes = b64uToUint8(k.key);
                        function baru() { return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyBytes }); }
                        return reg.pushManager.getSubscription().then(function (sub) {
                            if (!sub) return baru();
                            if (force || !sameKey(sub, keyBytes)) {
                                return sendSub(sub, 'unsubscribe').catch(function () {}).then(function () {
                                    return sub.unsubscribe();
                                }).then(baru);
                            }
                            return sub;
                        });
                    });
            }).then(function (sub) {
                return sendSub(sub, 'subscribe');
            });
        }

        (function addBell() {
            var holder = document.querySelector('.section-header > div');
            if (!holder) return;
            var btn = document.createElement('button');
            btn.id = 'notif-bell'; btn.type = 'button';
            function paint() {
                var ok = pushActive;
                btn.className = ok ? 'on' : ''; btn.textContent = ok ? '🔔 On' : '🔔';
            }
            // Cek status langganan saat halaman dibuka
            if (pushSupported && Notification.permission === 'granted') {
                enablePush().then(function () { pushActive = true; paint(); }).catch(function () { paint(); });
            }
            btn.onclick = function () {
                unlockAudio(); beep();
                if (!pushSupported) {
                    toast('Belum didukung', 'Browser ini tidak mendukung notifikasi layar HP. Gunakan Chrome terbaru (Android).', location.href, true);
                    return;
                }
                if (Notification.permission === 'denied') {
                    toast('Notifikasi diblokir', 'Buka pengaturan situs di Chrome > Notifikasi > Izinkan, lalu ketuk 🔔 lagi.', location.href, true);
                    return;
                }
                Notification.requestPermission().then(function (p) {
                    if (p !== 'granted') { paint(); return; }
                    return enablePush(true).then(function () {
                        pushActive = true; paint();
                        toast('Notifikasi layar HP aktif', 'Pesanan & user baru akan muncul di layar HP walau Chrome ditutup.', location.href);
                    });
                }).catch(function (err) {
                    paint();
                    toast('Gagal mengaktifkan', String(err && err.message ? err.message : err), location.href, true);
                });
            };
            paint();
            holder.insertBefore(btn, holder.firstChild);
        })();

        // ----- Polling -----
        function poll() {
            var url = 'admin_dashboard.php?notif=1&o=' + seenOrder + '&u=' + seenUser + '&_=' + Date.now();
            fetch(url, { credentials: 'same-origin', cache: 'no-store' })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    var orderBadge = badgeFor('tab=situs'), userBadge = badgeFor('tab=users'), prodBadge = badgeFor('tab=produk');
                    setBadge(orderBadge, ACTIVE_TAB === 'situs' ? Math.max(0, d.max_order > PAGE_MAX_ORDER ? d.max_order - PAGE_MAX_ORDER : 0) : d.new_orders);
                    setBadge(userBadge,  ACTIVE_TAB === 'users' ? Math.max(0, d.max_user  > PAGE_MAX_USER  ? d.max_user  - PAGE_MAX_USER  : 0) : d.new_users);
                    setBadge(prodBadge, d.stok_habis);

                    var newOrderCount = (ACTIVE_TAB === 'situs') ? Math.max(0, d.max_order - PAGE_MAX_ORDER) : d.new_orders;
                    var newUserCount  = (ACTIVE_TAB === 'users') ? Math.max(0, d.max_user  - PAGE_MAX_USER)  : d.new_users;

                    if (notifiedOrder === null) { notifiedOrder = PAGE_MAX_ORDER; notifiedUser = PAGE_MAX_USER; }

                    // Pesanan baru
                    if (d.max_order > notifiedOrder) {
                        var lo = d.last_order || {};
                        var jml = d.max_order - notifiedOrder;
                        toast('🛒 Pesanan baru' + (jml > 1 ? ' (' + jml + ')' : ''),
                              (lo.user || 'Pembeli') + (lo.produk ? ' memesan ' + lo.produk : ' membuat pesanan') + '. Total pending: ' + d.pending,
                              'admin_dashboard.php?tab=situs');
                        notifiedOrder = d.max_order;
                    }
                    // User baru
                    if (d.max_user > notifiedUser) {
                        var ju = d.max_user - notifiedUser;
                        toast('👤 User baru' + (ju > 1 ? ' (' + ju + ')' : ''),
                              (d.last_user || 'Pembeli baru') + ' baru saja mendaftar.',
                              'admin_dashboard.php?tab=users');
                        notifiedUser = d.max_user;
                    }
                    // Stok habis (hanya kalau bertambah)
                    if (d.stok_habis > lastHabis) {
                        toast('⚠️ Stok habis', d.habis_nama || 'Ada produk yang stoknya 0.', 'admin_dashboard.php?tab=produk', true);
                    }
                    if (d.stok_habis !== lastHabis) { lastHabis = d.stok_habis; lsSet('alzz_habis', lastHabis); }

                    // Saat dashboard baru dibuka: beritahu jika ada yang belum dilihat
                    if (firstPoll) {
                        firstPoll = false;
                        if (ACTIVE_TAB !== 'situs' && d.new_orders > 0)
                            toast('🛒 ' + d.new_orders + ' pesanan belum dilihat', 'Sejak terakhir Anda membuka daftar pesanan.', 'admin_dashboard.php?tab=situs');
                        if (ACTIVE_TAB !== 'users' && d.new_users > 0)
                            toast('👤 ' + d.new_users + ' user baru belum dilihat', 'Sejak terakhir Anda membuka daftar user.', 'admin_dashboard.php?tab=users');
                    }
                })
                .catch(function () { /* abaikan error jaringan sementara */ });
        }

        poll();
        setInterval(poll, POLL_MS);
        document.addEventListener('visibilitychange', function () { if (!document.hidden) poll(); });
    })();
    </script>

</body>
</html>
