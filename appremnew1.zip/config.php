<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Aktifkan pelacakan error untuk debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = "sql202.infinityfree.com";
$user = "if0_43146300";
$pass = "wxoSEKuqYpN";
$db   = "if0_43146300_alzzstore";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi DB gagal: " . mysqli_connect_error());
}
?>
