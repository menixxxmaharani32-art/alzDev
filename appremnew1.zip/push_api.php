<?php
// API kecil untuk notifikasi push (hanya admin yang sudah login)
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once 'auth_guard.php';
require_once 'config.php';
require_once 'push_lib.php';

if (empty($_SESSION['admin_logged'])) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}
alzz_push_tables($conn);
$action = $_GET['action'] ?? '';

if ($action === 'key') {
    $v = alzz_vapid($conn);
    echo json_encode(['key' => $v ? $v['public'] : null]);
    exit;
}

if ($action === 'subscribe' || $action === 'unsubscribe') {
    $in = json_decode(file_get_contents('php://input'), true);
    $endpoint = $in['endpoint'] ?? '';
    if (!is_string($endpoint) || strpos($endpoint, 'https://') !== 0) {
        http_response_code(400);
        echo json_encode(['error' => 'endpoint tidak valid']);
        exit;
    }
    $hash = hash('sha256', $endpoint);
    $ep = mysqli_real_escape_string($conn, $endpoint);
    if ($action === 'subscribe') {
        mysqli_query($conn, "REPLACE INTO push_subs (endpoint_hash, endpoint, created_at) VALUES ('$hash', '$ep', NOW())");
    } else {
        mysqli_query($conn, "DELETE FROM push_subs WHERE endpoint_hash = '$hash'");
    }
    echo json_encode(['ok' => true]);
    exit;
}

if ($action === 'events') {
    $since = intval($_GET['since'] ?? 0);
    $where = $since > 0 ? "id > $since" : "created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)";
    $r = mysqli_query($conn, "SELECT id, type, title, body, url FROM push_events WHERE $where ORDER BY id ASC LIMIT 10");
    $out = [];
    while ($r && ($row = mysqli_fetch_assoc($r))) { $row['id'] = intval($row['id']); $out[] = $row; }
    echo json_encode(['events' => $out]);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'action tidak dikenal']);
